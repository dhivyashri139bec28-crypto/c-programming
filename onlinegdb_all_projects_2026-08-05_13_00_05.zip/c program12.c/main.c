/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
struct  product{
    int c;
};
void calproduct(int*a,int*b,struct product*result){
    result->c=(*a)*(*b);
}
int main()
{
    int x,y;
    struct product result;
    printf("enter the numbers");
    scanf("%d%d ",&x,&y);
    calproduct(&x,&y,&result);
    printf("the product is:%d%d%d",x,y,result.c);
    return 0;
}



    
    