/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b,c;
   printf("\nenter a");
   scanf("%d",&a);
   printf("\n enter b");
   scanf("%d",&b);
   c=a+b;
   printf("\n sum of addition %d",c);
   c=a-b;
   printf("\n difference %d",c);
   c=a*b;
   printf("\n product is %d",c);
   c=a/b;
   printf("\n division is %d",c);
   c=a%b;
   printf("\n modulus is %d",c);
   return 0;
   
}
