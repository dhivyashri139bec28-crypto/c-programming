/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//logical operations
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("\n enter a,b,c values:");
    scanf("%d %d %d",&a,&b,&c);
    if(a>b && a>c){
        printf("a is big");
    }
    else if(b>c){
        printf("b is big");
    }
    else{
        printf("c is big");

    return 0;
}
