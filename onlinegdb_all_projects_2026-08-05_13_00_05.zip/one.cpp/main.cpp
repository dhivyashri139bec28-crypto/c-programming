/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

struct Date {
    int dd;
    int mm;
    int yy;
};

struct Account {
    int accountNumber;
    string accountHolderName;
    string accountType; 
    double balance;
    Date lastWithdrawalDate; 
    Account* next;

    Account(int accNum, const string& name, const string& type, double initialBalance)
        : accountNumber(accNum), accountHolderName(name), accountType(type), balance(initialBalance), next(nullptr) {
        lastWithdrawalDate = {0, 0, 0}; 
    }
};

class BankManagement {
private:
    Account* head; // Initialize head pointer to nullptr

public:
    BankManagement() {
                    head= nullptr;

    } // Constructor initializes head to nullptr

    void createAccount(int accNum, const string& name, const string& type, double initialBalance) {
        Account* newAccount = new Account(accNum, name, type, initialBalance);
        newAccount->next = head;
        head = newAccount;
        cout << "Account created successfully for " << name << " with account number " << accNum << endl;
    }

    void deposit(int accNum, double amount) {
        Account* current = head;
        while (current != nullptr) {
            if (current->accountNumber == accNum) {
                current->balance += amount;
                cout << "Deposited " << amount << " to account number " << accNum << endl;
                return;
            }
            current = current->next;
        }
        cout << "Account number " << accNum << " not found." << endl;
    }

    void withdraw(int accNum, double amount) {
        Account* current = head;
        while (current != nullptr) {
            if (current->accountNumber == accNum) {
                if (current->balance >= amount) {
                    current->balance -= amount;
                    cout << "Withdrew " << amount << " from account number " << accNum << endl;

                    // Set the last withdrawal date
                    cout << "Enter withdrawal date (dd mm yyyy): ";
                    cin >> current->lastWithdrawalDate.dd >> current->lastWithdrawalDate.mm >> current->lastWithdrawalDate.yy;

                    return;
                } else {
                    cout << "Insufficient balance in account number " << accNum << endl;
                }
                return;
            }
            current = current->next;
        }
        cout << "Account number " << accNum << " not found." << endl;
    }

    void displayAccount(int accNum) {
        Account* current = head;
        while (current != nullptr) {
            if (current->accountNumber == accNum) {
                cout << "Account Number: " << current->accountNumber << endl;
                cout << "Account Holder Name: " << current->accountHolderName << endl;
                cout << "Account Type: " << current->accountType << endl;
                cout << "Balance: " << current->balance << endl;
                cout << "Last Withdrawal Date: " << current->lastWithdrawalDate.dd << "/"
                     << current->lastWithdrawalDate.mm << "/" << current->lastWithdrawalDate.yy << endl;
                return;
            }
            current = current->next;
        }
        cout << "Account number " << accNum << " not found." << endl;
    }

    void deleteAccount(int accNum) {
        if (head == nullptr) {
            cout << "No accounts to delete." << endl;
            return;
        }

        if (head->accountNumber == accNum) {
            Account* temp = head;
            head = head->next;
            delete temp;
            cout << "Account number " << accNum << " deleted successfully." << endl;
            return;
        }

        Account* current = head;
        while (current->next != nullptr) {
            if (current->next->accountNumber == accNum) {
                Account* temp = current->next;
                current->next = temp->next;
                delete temp;
                cout << "Account number " << accNum << " deleted successfully." << endl;
                return;
            }
            current = current->next;
        }
        cout << "Account number " << accNum << " not found." << endl;
    }

    void displayAllAccounts() {
        Account* current = head;
        if (current == nullptr) {
            cout << "No accounts available." << endl;
            return;
        }
        while (current != nullptr) {
            cout << "Account Number: " << current->accountNumber << ", "
                 << "Account Holder Name: " << current->accountHolderName << ", "
                 << "Account Type: " << current->accountType << ", "
                 << "Balance: " << current->balance << ", "
                 << "Last Withdrawal Date: " << current->lastWithdrawalDate.dd << "/"
                 << current->lastWithdrawalDate.mm << "/" << current->lastWithdrawalDate.yy << endl;
            current = current->next;
        }
    }

    ~BankManagement() {
        while (head != nullptr) {
            Account* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main() {
    BankManagement bank;
    int choice;

    do {
        cout << "\nBank Management System" << endl;
        cout << "1. Create Account" << endl;
        cout << "2. Deposit Money" << endl;
        cout << "3. Withdraw Money" << endl;
        cout << "4. Display Account" << endl;
        cout << "5. Delete Account" << endl;
        cout << "6. Display All Accounts" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int accNum;
                string name, type;
                double initialBalance;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter account holder name: ";
                cin.ignore();
                getline(cin, name);
                cout << "Enter account type (e.g., Savings, Current): ";
                getline(cin, type);
                cout << "Enter initial balance: ";
                cin >> initialBalance;
                bank.createAccount(accNum, name, type, initialBalance);
                break;
            }
            case 2: {
                int accNum;
                double amount;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter amount to deposit: ";
                cin >> amount;
                bank.deposit(accNum, amount);
                break;
            }
            case 3: {
                int accNum;
                double amount;
                cout << "Enter account number: ";
                cin >> accNum;
                cout << "Enter amount to withdraw: ";
                cin >> amount;
                bank.withdraw(accNum, amount);
                break;
            }
            case 4: {
                int accNum;
                cout << "Enter account number: ";
                cin >> accNum;
                bank.displayAccount(accNum);
                break;
            }
            case 5: {
                int accNum;
                cout << "Enter account number to delete: ";
                cin >> accNum;
                bank.deleteAccount(accNum);
                break;
            }
            case 6:
                bank.displayAllAccounts();
                break;
            case 0:
                cout << "Exiting the program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}


