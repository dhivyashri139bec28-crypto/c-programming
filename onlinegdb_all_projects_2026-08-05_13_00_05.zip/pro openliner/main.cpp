/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Bank Management using Hashing (Linear Probing)
#include <iostream>
#include <iomanip>
#define TABLE_SIZE 13
using namespace std;

class HashTable {
private:
    struct Node {
        int accountNo;
        string holderName;
        string accountType;
        string withdrawalDate;
        float balance;
        bool occupied; // indicates whether a cell is filled
    } table[TABLE_SIZE];

public:
    HashTable();
    int hash(int);
    void insert(int, string, string, string, float);
    void display();
    int search(int);
    void deleteAccount(int);
};

// Initialize Hash Table
HashTable::HashTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        table[i].accountNo = -1;
        table[i].occupied = false;
    }
}

// Hash Function
int HashTable::hash(int key) {
    return key % TABLE_SIZE;
}

// Insert record using linear probing
void HashTable::insert(int accNo, string name, string type, string date, float bal) {
    int index = hash(accNo);
    int i = 0;

    while (table[(index + i) % TABLE_SIZE].occupied && i < TABLE_SIZE) {
        i++;
    }

    if (i == TABLE_SIZE) {
        cout << "\nHash Table Full! Cannot insert more records.\n";
        return;
    }

    int newIndex = (index + i) % TABLE_SIZE;
    table[newIndex].accountNo = accNo;
    table[newIndex].holderName = name;
    table[newIndex].accountType = type;
    table[newIndex].withdrawalDate = date;
    table[newIndex].balance = bal;
    table[newIndex].occupied = true;

    cout << "\nRecord inserted successfully at index " << newIndex << ".";
}

// Display all records
void HashTable::display() {
    cout << "\n-------------------------------------------------------------------------------------";
    cout << "\nIndex\tAccount No\tHolder Name\tType\tWithdrawal Date\tBalance";
    cout << "\n-------------------------------------------------------------------------------------";
    for (int i = 0; i < TABLE_SIZE; i++) {
        cout << "\n" << setw(5) << i << "\t";
        if (table[i].occupied) {
            cout << setw(10) << table[i].accountNo << "\t"
                 << setw(12) << table[i].holderName << "\t"
                 << setw(6) << table[i].accountType << "\t"
                 << setw(14) << table[i].withdrawalDate << "\t"
                 << fixed << setprecision(2) << table[i].balance;
        } else {
            cout << "-";
        }
    }
    cout << "\n-------------------------------------------------------------------------------------\n";
}

// Search for an account
int HashTable::search(int accNo) {
    int index = hash(accNo);
    int i = 0;

    while (i < TABLE_SIZE) {
        int pos = (index + i) % TABLE_SIZE;
        if (table[pos].occupied && table[pos].accountNo == accNo) {
            cout << "\nAccount found at index " << pos << ":\n";
            cout << "Account No: " << table[pos].accountNo
                 << "\nHolder Name: " << table[pos].holderName
                 << "\nAccount Type: " << table[pos].accountType
                 << "\nWithdrawal Date: " << table[pos].withdrawalDate
                 << "\nBalance: " << table[pos].balance << "\n";
            return pos;
        }
        i++;
    }

    cout << "\nAccount not found!\n";
    return -1;
}

// Delete an account
void HashTable::deleteAccount(int accNo) {
    int pos = search(accNo);
    if (pos != -1) {
        table[pos].occupied = false;
        table[pos].accountNo = -1;
        cout << "\nAccount deleted successfully!\n";
    }
}

int main() {
    HashTable bank;
    int choice;
    do {
        cout << "\n========== BANK MANAGEMENT USING HASHING ==========";
        cout << "\n1. Insert Account";
        cout << "\n2. Display Table";
        cout << "\n3. Search Account";
        cout << "\n4. Delete Account";
        cout << "\n5. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int accNo;
                string name, type, date;
                float balance;
                cout << "\nEnter Account No: ";
                cin >> accNo;
                cout << "Enter Holder Name: ";
                cin >> name;
                cout << "Enter Account Type (Savings/Current): ";
                cin >> type;
                cout << "Enter Withdrawal Date (DD/MM/YYYY): ";
                cin >> date;
                cout << "Enter Balance Amount: ";
                cin >> balance;
                bank.insert(accNo, name, type, date, balance);
                break;
            }
            case 2:
                bank.display();
                break;
            case 3: {
                int accNo;
                cout << "\nEnter Account No to search: ";
                cin >> accNo;
                bank.search(accNo);
                break;
            }
            case 4: {
                int accNo;
                cout << "\nEnter Account No to delete: ";
                cin >> accNo;
                bank.deleteAccount(accNo);
                break;
            }
            case 5:
                cout << "\nExiting...\n";
                break;
            default:
                cout << "\nInvalid choice! Try again.\n";
        }
    } while (choice != 5);

    return 0;
}
