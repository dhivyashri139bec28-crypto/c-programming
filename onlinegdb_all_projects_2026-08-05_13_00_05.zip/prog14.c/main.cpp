/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
struct product{
    int c;
};
void  calproduct(int*a,int*b,product*s){
    s->c=(*a)*(*b);
}
int main()
{
    int x,y;
    struct product s;
    cout<<"enter the x \t and  \ty ";
    cin>>x>>y;
    calproduct(&x,&y,&s);
    cout<<"the product is :"<<s.c;
    return 0;
    
}