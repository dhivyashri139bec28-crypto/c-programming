/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;

// Define date structure
struct date {
    int dd, mm, yyyy;
};

// Define account structure
struct Account {
    int accountno;
    string accountholder;
    string accounttype;
    date withdrawalDate;
    float balance_amount;
};

// ---------------- Base Class ----------------
class BankRecords {
protected:
    Account acc[20];
    int n;

public:
    void getData();
    void display();
};

// Input function
void BankRecords::getData() {
    cout << "\nEnter number of accounts: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        cout << "\nEnter details of Account " << i + 1 << ":\n";
        cout << "Account No: ";
        cin >> acc[i].accountno;
        cout << "Account Holder Name: ";
        cin >> acc[i].accountholder;
        cout << "Account Type (Savings/Current): ";
        cin >> acc[i].accounttype;
        cout << "Date of Withdrawal (dd mm yyyy): ";
        cin >> acc[i].withdrawalDate.dd >> acc[i].withdrawalDate.mm >> acc[i].withdrawalDate.yyyy;
        cout << "Balance Amount: ";
        cin >> acc[i].balance_amount;
    }
}

// Display function
void BankRecords::display() {
    cout << "\n-------------------------------------------------------------";
    cout << "\nAcc.No\tHolder\tType\tDate\t\tBalance";
    cout << "\n-------------------------------------------------------------";
    for (int i = 0; i < n; i++) {
        cout << "\n" << acc[i].accountno << "\t"
             << acc[i].accountholder << "\t"
             << acc[i].accounttype << "\t"
             << acc[i].withdrawalDate.dd << "/" 
             << acc[i].withdrawalDate.mm << "/" 
             << acc[i].withdrawalDate.yyyy << "\t"
             << acc[i].balance_amount;
    }
    cout << "\n-------------------------------------------------------------\n";
}

// ---------------- Derived Class: Bubble Sort ----------------
class BubbleSort : public BankRecords {
public:
    void sort();
};

void BubbleSort::sort() {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (acc[j].balance_amount > acc[j + 1].balance_amount) {
                Account temp = acc[j];
                acc[j] = acc[j + 1];
                acc[j + 1] = temp;
            }
        }
    }
    cout << "\nRecords Sorted by Balance (Bubble Sort):\n";
    display();
}

// ---------------- Derived Class: Insertion Sort ----------------
class InsertionSort : public BankRecords {
public:
    void sort();
};

void InsertionSort::sort() {
    for (int i = 1; i < n; i++) {
        Account key = acc[i];
        int j = i - 1;
        while (j >= 0 && acc[j].balance_amount > key.balance_amount) {
            acc[j + 1] = acc[j];
            j--;
        }
        acc[j + 1] = key;
    }
    cout << "\nRecords Sorted by Balance (Insertion Sort):\n";
    display();
}

// ---------------- Derived Class: Quick Sort ----------------
class QuickSort : public BankRecords {
public:
    void sort();

private:
    void quickSort(int low, int high);
    int partition(int low, int high);
};

int QuickSort::partition(int low, int high) {
    float pivot = acc[high].balance_amount;
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (acc[j].balance_amount < pivot) {
            i++;
            Account temp = acc[i];
            acc[i] = acc[j];
            acc[j] = temp;
        }
    }
    Account temp = acc[i + 1];
    acc[i + 1] = acc[high];
    acc[high] = temp;
    return i + 1;
}

void QuickSort::quickSort(int low, int high) {
    if (low < high) {
        int pi = partition(low, high);
        quickSort(low, pi - 1);
        quickSort(pi + 1, high);
    }
}

void QuickSort::sort() {
    quickSort(0, n - 1);
    cout << "\nRecords Sorted by Balance (Quick Sort):\n";
    display();
}

// ---------------- Derived Class: Merge Sort ----------------
class MergeSort : public BankRecords {
public:
    void sort();

private:
    void mergeSort(int left, int right);
    void merge(int left, int mid, int right);
};

void MergeSort::merge(int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Account L[20], R[20];
    for (int i = 0; i < n1; i++)
        L[i] = acc[left + i];
    for (int j = 0; j < n2; j++)
        R[j] = acc[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i].balance_amount <= R[j].balance_amount) {
            acc[k] = L[i];
            i++;
        } else {
            acc[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        acc[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        acc[k] = R[j];
        j++;
        k++;
    }
}

void MergeSort::mergeSort(int left, int right) {
    if (left < right) {
        int mid = (left + right) / 2;
        mergeSort(left, mid);
        mergeSort(mid + 1, right);
        merge(left, mid, right);
    }
}

void MergeSort::sort() {
    mergeSort(0, n - 1);
    cout << "\nRecords Sorted by Balance (Merge Sort):\n";
    display();
}

// ---------------- MAIN PROGRAM ----------------
int main() {
    int choice;
    do {
        cout << "\n========= BANK RECORD SORTING SYSTEM =========";
        cout << "\n1. Bubble Sort";
        cout << "\n2. Insertion Sort";
        cout << "\n3. Quick Sort";
        cout << "\n4. Merge Sort";
        cout << "\n5. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            BubbleSort bs;
            bs.getData();
            bs.sort();
            break;
        }
        case 2: {
            InsertionSort is;
            is.getData();
            is.sort();
            break;
        }
        case 3: {
            QuickSort qs;
            qs.getData();
            qs.sort();
            break;
        }
        case 4: {
            MergeSort ms;
            ms.getData();
            ms.sort();
            break;
        }
        case 5:
            cout << "\nExiting program...\n";
            break;
        default:
            cout << "\nInvalid choice! Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
